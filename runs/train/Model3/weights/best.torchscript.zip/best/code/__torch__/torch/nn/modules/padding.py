class ZeroPad2d(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.padding.ZeroPad2d,
    argument_1: Tensor) -> Tensor:
    input = torch.pad(argument_1, [0, 1, 0, 1], "constant", 0.)
    return input
