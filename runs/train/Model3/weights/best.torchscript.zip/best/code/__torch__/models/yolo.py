class DetectionModel(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  model : __torch__.torch.nn.modules.container.Sequential
  def forward(self: __torch__.models.yolo.DetectionModel,
    x: Tensor) -> Tuple[Tensor]:
    model = self.model
    _20 = getattr(model, "20")
    model0 = self.model
    _19 = getattr(model0, "19")
    model1 = self.model
    _18 = getattr(model1, "18")
    model2 = self.model
    _17 = getattr(model2, "17")
    model3 = self.model
    _16 = getattr(model3, "16")
    model4 = self.model
    _15 = getattr(model4, "15")
    model5 = self.model
    _14 = getattr(model5, "14")
    model6 = self.model
    _13 = getattr(model6, "13")
    model7 = self.model
    _12 = getattr(model7, "12")
    model8 = self.model
    _11 = getattr(model8, "11")
    model9 = self.model
    _10 = getattr(model9, "10")
    model10 = self.model
    _9 = getattr(model10, "9")
    model11 = self.model
    _8 = getattr(model11, "8")
    model12 = self.model
    _7 = getattr(model12, "7")
    model13 = self.model
    _6 = getattr(model13, "6")
    model14 = self.model
    _5 = getattr(model14, "5")
    model15 = self.model
    _4 = getattr(model15, "4")
    model16 = self.model
    _3 = getattr(model16, "3")
    model17 = self.model
    _2 = getattr(model17, "2")
    model18 = self.model
    _1 = getattr(model18, "1")
    model19 = self.model
    _190 = getattr(model19, "19")
    act = _190.act
    model20 = self.model
    _0 = getattr(model20, "0")
    _21 = (_1).forward((_0).forward(act, x, ), )
    _22 = (_3).forward((_2).forward(act, _21, ), )
    _23 = (_5).forward((_4).forward(act, _22, ), )
    _24 = (_7).forward((_6).forward(act, _23, ), )
    _25 = (_8).forward(act, _24, )
    _26 = (_10).forward(act, (_9).forward(_25, ), )
    _27 = (_12).forward((_11).forward(_26, ), )
    _28 = (_14).forward(act, (_13).forward(act, _27, ), )
    _29 = (_15).forward(act, _28, )
    _30 = (_17).forward((_16).forward(act, _28, ), )
    _31 = (_19).forward((_18).forward(_30, _25, ), )
    return ((_20).forward(_31, _29, ),)
class Detect(Module):
  __parameters__ = []
  __buffers__ = ["anchors", ]
  anchors : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  m : __torch__.torch.nn.modules.container.ModuleList
  def forward(self: __torch__.models.yolo.Detect,
    argument_1: Tensor,
    argument_2: Tensor) -> Tensor:
    m = self.m
    _1 = getattr(m, "1")
    m0 = self.m
    _0 = getattr(m0, "0")
    _11 = (_0).forward(argument_1, )
    bs = ops.prim.NumToTensor(torch.size(_11, 0))
    _12 = int(bs)
    _13 = int(bs)
    ny = ops.prim.NumToTensor(torch.size(_11, 2))
    _14 = int(ny)
    nx = ops.prim.NumToTensor(torch.size(_11, 3))
    _15 = torch.view(_11, [_13, 3, 8, _14, int(nx)])
    _16 = torch.contiguous(torch.permute(_15, [0, 1, 3, 4, 2]))
    _17 = torch.split_with_sizes(torch.sigmoid(_16), [2, 2, 4], 4)
    xy, wh, conf, = _17
    _18 = torch.add(torch.mul(xy, CONSTANTS.c0), CONSTANTS.c1)
    xy0 = torch.mul(_18, torch.select(CONSTANTS.c2, 0, 0))
    _19 = torch.pow(torch.mul(wh, CONSTANTS.c0), 2)
    wh0 = torch.mul(_19, CONSTANTS.c3)
    y = torch.cat([xy0, wh0, conf], 4)
    _20 = torch.mul(torch.mul(nx, CONSTANTS.c4), ny)
    _21 = torch.view(y, [_12, int(_20), 8])
    _22 = (_1).forward(argument_2, )
    bs0 = ops.prim.NumToTensor(torch.size(_22, 0))
    _23 = int(bs0)
    _24 = int(bs0)
    ny0 = ops.prim.NumToTensor(torch.size(_22, 2))
    _25 = int(ny0)
    nx0 = ops.prim.NumToTensor(torch.size(_22, 3))
    _26 = torch.view(_22, [_24, 3, 8, _25, int(nx0)])
    _27 = torch.contiguous(torch.permute(_26, [0, 1, 3, 4, 2]))
    _28 = torch.split_with_sizes(torch.sigmoid(_27), [2, 2, 4], 4)
    xy1, wh1, conf0, = _28
    _29 = torch.add(torch.mul(xy1, CONSTANTS.c0), CONSTANTS.c5)
    xy2 = torch.mul(_29, torch.select(CONSTANTS.c2, 0, 1))
    _30 = torch.pow(torch.mul(wh1, CONSTANTS.c0), 2)
    wh2 = torch.mul(_30, CONSTANTS.c6)
    y0 = torch.cat([xy2, wh2, conf0], 4)
    _31 = torch.mul(torch.mul(nx0, CONSTANTS.c4), ny0)
    _32 = [_21, torch.view(y0, [_23, int(_31), 8])]
    return torch.cat(_32, 1)
